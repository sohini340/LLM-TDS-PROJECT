import os
from PIL import Image
import pytesseract

DATA_DIR = "data"

def extract_credit_card():
    """Extracts credit card number from an image using OCR."""
    file_path = os.path.join(DATA_DIR, "credit-card.png")
    image = Image.open(file_path)
    card_number = pytesseract.image_to_string(image).replace(" ", "")

    output_path = os.path.join(DATA_DIR, "credit-card.txt")
    with open(output_path, "w") as file:
        file.write(card_number)

    return "Credit card number extracted."
