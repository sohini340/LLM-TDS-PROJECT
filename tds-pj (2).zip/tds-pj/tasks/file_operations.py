import os

DATA_DIR = "data"

def extract_recent_logs():
    """Extracts first lines from the most recent log files."""
    log_dir = os.path.join(DATA_DIR, "logs")
    log_files = sorted(os.listdir(log_dir), key=lambda x: os.path.getmtime(os.path.join(log_dir, x)), reverse=True)

    log_lines = []
    for log_file in log_files[:10]:
        with open(os.path.join(log_dir, log_file)) as f:
            log_lines.append(f.readline().strip())

    output_path = os.path.join(DATA_DIR, "logs-recent.txt")
    with open(output_path, "w") as file:
        file.write("\n".join(log_lines))

    return "Extracted 10 most recent log lines."
