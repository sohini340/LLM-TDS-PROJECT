import os
import pytest
from tasks import count_wednesdays, sort_contacts, extract_recent_logs

def test_count_wednesdays():
    """Test counting Wednesdays from a date file."""
    test_file = "data/dates.txt"
    with open(test_file, "w") as f:
        f.write("2024-01-03\n2024-01-10\n2024-01-17\n")
    
    result = count_wednesdays()
    assert "Counted 3 Wednesdays" in result

def test_sort_contacts():
    """Test sorting contacts.json"""
    test_file = "data/contacts.json"
    with open(test_file, "w") as f:
        f.write('[{"first_name": "Alice", "last_name": "Zane"}, {"first_name": "Bob", "last_name": "Adams"}]')

    result = sort_contacts()
    assert os.path.exists("data/contacts-sorted.json")

def test_extract_recent_logs():
    """Test extracting recent logs"""
    log_dir = "data/logs"
    os.makedirs(log_dir, exist_ok=True)
    for i in range(3):
        with open(f"{log_dir}/log{i}.log", "w") as f:
            f.write(f"Log {i} content\n")

    result = extract_recent_logs()
    assert os.path.exists("data/logs-recent.txt")

