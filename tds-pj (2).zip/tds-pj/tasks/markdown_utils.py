import os
import json

DATA_DIR = "data"

def extract_markdown_titles():
    """Extracts H1 titles from Markdown files."""
    docs_dir = os.path.join(DATA_DIR, "docs")
    index = {}

    for file_name in os.listdir(docs_dir):
        if file_name.endswith(".md"):
            with open(os.path.join(docs_dir, file_name)) as file:
                for line in file:
                    if line.startswith("# "):
                        index[file_name] = line[2:].strip()
                        break

    output_path = os.path.join(DATA_DIR, "docs/index.json")
    with open(output_path, "w") as file:
        json.dump(index, file, indent=4)
    
    return "Markdown index created."
