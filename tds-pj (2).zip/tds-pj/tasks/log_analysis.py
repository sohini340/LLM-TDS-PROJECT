import os

DATA_DIR = "data"

def analyze_logs():
    """Extracts error messages from logs."""
    log_dir = os.path.join(DATA_DIR, "logs")
    output_path = os.path.join(DATA_DIR, "logs-errors.txt")

    error_lines = []
    for log_file in os.listdir(log_dir):
        with open(os.path.join(log_dir, log_file)) as f:
            for line in f:
                if "ERROR" in line:
                    error_lines.append(line.strip())

    with open(output_path, "w") as file:
        file.write("\n".join(error_lines))

    return "Extracted error logs."
