import os
import json
import datetime

DATA_DIR = "data"

def count_wednesdays():
    """Counts the number of Wednesdays in the date file."""
    file_path = os.path.join(DATA_DIR, "dates.txt")
    with open(file_path, "r") as file:
        dates = [line.strip() for line in file.readlines()]
    
    wednesday_count = sum(1 for date in dates if datetime.datetime.strptime(date, "%Y-%m-%d").weekday() == 2)

    output_path = os.path.join(DATA_DIR, "dates-wednesdays.txt")
    with open(output_path, "w") as f:
        f.write(str(wednesday_count))
    
    return f"Counted {wednesday_count} Wednesdays."

def sort_contacts():
    """Sorts contacts.json by last_name and first_name."""
    file_path = os.path.join(DATA_DIR, "contacts.json")
    with open(file_path, "r") as file:
        contacts = json.load(file)

    contacts.sort(key=lambda x: (x.get("last_name", ""), x.get("first_name", "")))

    output_path = os.path.join(DATA_DIR, "contacts-sorted.json")
    with open(output_path, "w") as file:
        json.dump(contacts, file, indent=4)
    
    return "Contacts sorted successfully."
