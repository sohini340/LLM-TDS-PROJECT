import os
from tasks.data_processing import count_wednesdays, sort_contacts
from tasks.file_operations import extract_recent_logs
from tasks.log_analysis import analyze_logs
from tasks.markdown_utils import extract_markdown_titles
from tasks.image_processing import extract_credit_card
from tasks.db_operations import calculate_gold_ticket_sales
from tasks.similarity import find_similar_comments
from tasks.email_processing import extract_email_sender

def execute_task(task: str):
    """Routes task requests to appropriate function."""
    task_lower = task.lower()

    if "count wednesdays" in task_lower:
        return count_wednesdays()

    elif "sort contacts" in task_lower:
        return sort_contacts()

    elif "extract log lines" in task_lower:
        return extract_recent_logs()

    elif "extract h1" in task_lower:
        return extract_markdown_titles()

    elif "extract sender email" in task_lower:
        return extract_email_sender()

    elif "extract credit card" in task_lower:
        return extract_credit_card()

    elif "find similar comments" in task_lower:
        return find_similar_comments()

    elif "total sales for gold tickets" in task_lower:
        return calculate_gold_ticket_sales()

    else:
        raise ValueError(f"Unknown task: {task}")
