import os
import sqlite3

DATA_DIR = "data"

def calculate_gold_ticket_sales():
    """Calculates total sales for 'Gold' tickets."""
    db_path = os.path.join(DATA_DIR, "ticket-sales.db")
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT SUM(units * price) FROM tickets WHERE type = 'Gold'")
    total_sales = cursor.fetchone()[0]
    conn.close()

    output_path = os.path.join(DATA_DIR, "ticket-sales-gold.txt")
    with open(output_path, "w") as file:
        file.write(str(total_sales))

    return f"Total sales for Gold tickets: {total_sales}"
